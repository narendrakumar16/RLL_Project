package com.admin.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.admin.entity.AddResult;



public interface AddResultRepo extends JpaRepository<AddResult, Integer>{

}
