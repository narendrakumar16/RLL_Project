package com.admin.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="students")
public class Student {
	@Id
private int stid;
private String name;
private String email;
private String phone;
private String pin;
private String department;
private String batch;

public Student() {}


public Student(int stid, String name, String email, String phone, String pin, String department, String batch) {
	super();
	this.stid = stid;
	this.name = name;
	this.email = email;
	this.phone = phone;
	this.pin = pin;
	this.department = department;
	this.batch = batch;
}
public int getStid() {
	return stid;
}
public void setStid(int stid) {
	this.stid = stid;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getPhone() {
	return phone;
}
public void setPhone(String phone) {
	this.phone = phone;
}
public String getPin() {
	return pin;
}
public void setPin(String pin) {
	this.pin = pin;
}
public String getDepartment() {
	return department;
}
public void setDepartment(String department) {
	this.department = department;
}
public String getBatch() {
	return batch;
}
public void setBatch(String batch) {
	this.batch = batch;
}
}
