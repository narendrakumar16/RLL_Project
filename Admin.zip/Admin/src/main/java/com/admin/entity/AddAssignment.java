package com.admin.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="assignment")

public class AddAssignment {
	@Id
	private int studID;
	private String name;
	private String department;
	private String assignment;
	
	public AddAssignment() {}
	
	public AddAssignment(int studID, String name, String department, String assignment) {
		super();
		this.studID = studID;
		this.name = name;
		this.department = department;
		this.assignment = assignment;
	}
	public int getStudID() {
		return studID;
	}
	public void setStudID(int studID) {
		this.studID = studID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getAssignment() {
		return assignment;
	}
	public void setAssignment(String assignment) {
		this.assignment = assignment;
	}
}
