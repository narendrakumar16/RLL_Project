package com.admin.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="attendance")

public class AddAttendance {
	@Id
	private int studID;
	private String name;
	private String department;
	private String classesheld;
	private String attendance;
	
	public AddAttendance() {}
	
	public AddAttendance(int studID, String name, String department, String classesheld, String attendance) {
		super();
		this.studID = studID;
		this.name = name;
		this.department = department;
		this.classesheld = classesheld;
		this.attendance = attendance;
	}
	public int getStudID() {
		return studID;
	}
	public void setStudID(int studID) {
		this.studID = studID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getClassesheld() {
		return classesheld;
	}
	public void setClassesheld(String classesheld) {
		this.classesheld = classesheld;
	}
	public String getAttendance() {
		return attendance;
	}
	public void setAttendance(String attendance) {
		this.attendance = attendance;
	}
}
