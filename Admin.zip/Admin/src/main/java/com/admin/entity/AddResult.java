package com.admin.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="results")

public class AddResult {
	@Id
	private int studID;
	private String name;
	private String department;
	private String result;
	
	public AddResult() {}
	
	public AddResult(int studID, String name, String department, String result) {
		super();
		this.studID = studID;
		this.name = name;
		this.department = department;
		this.result = result;
	}
	public int getStudID() {
		return studID;
	}
	public void setStudID(int studID) {
		this.studID = studID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
}
