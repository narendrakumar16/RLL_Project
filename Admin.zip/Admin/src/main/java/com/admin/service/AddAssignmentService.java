package com.admin.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.admin.dao.AddAssignmentRepo;
import com.admin.entity.AddAssignment;

@Service
public class AddAssignmentService {
	@Autowired
	private AddAssignmentRepo assrepo;
	
	public List<AddAssignment> fetchAddAssignmentList(){
		return assrepo.findAll();
		
	}
	//add data
	public AddAssignment saveAddAssignmentToDB(AddAssignment addassignment)
	{
		return assrepo.save(addassignment);
	}
	
	//find by id
	public Optional<AddAssignment> fetchAddAssignmentById(int studID) {
		return assrepo.findById(studID);	
	}
}