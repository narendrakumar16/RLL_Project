package com.admin.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.admin.dao.AddAttendanceRepo;
import com.admin.entity.AddAttendance;

@Service
public class AddAttendanceService {
	@Autowired
	private AddAttendanceRepo attrepo;
	
	public List<AddAttendance> fetchAddAttendanceList(){
		return attrepo.findAll();
		
	}
	//add data
	public AddAttendance saveAddAttedanceToDB(AddAttendance addattendance)
	{
		return attrepo.save(addattendance);
	}
	
	//find by id
	public Optional<AddAttendance> fetchAddAttendanceById(int studID) {
		return attrepo.findById(studID);	
	}
}