package com.admin.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.admin.dao.AddResultRepo;
import com.admin.entity.AddResult;

@Service
public class AddResultService {
	@Autowired
	private AddResultRepo resrepo;
	
	public List<AddResult> fetchAddResultList(){
		return resrepo.findAll();
		
	}
	//add data
	public AddResult saveAddResultToDB(AddResult addresult)
	{
		return resrepo.save(addresult);
	}
	
	//find by id
	public Optional<AddResult> fetchAddResultById(int studID) {
		return resrepo.findById(studID);	
	}
}