package com.admin.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.admin.dao.AddFacultyRepo;
import com.admin.entity.AddFaculty;

@Service
public class AddFacultyService {
	@Autowired
	private AddFacultyRepo frepo;
	
	public List<AddFaculty> fetchAddFacultyList(){
		return frepo.findAll();
		
	}
	//add data
	public AddFaculty saveAddFacultyToDB(AddFaculty addfaculty)
	{
		return frepo.save(addfaculty);
	}
	
	//find by id
	public Optional<AddFaculty> fetchAddFacultyById(int fid) {
		return frepo.findById(fid);	
	}
	
public String deleteAddFacultyById(int fid) {
		
		String result;
		try { 
			frepo.deleteById(fid);
		result = "Faculty successfully deleted";
		
		
	}catch (Exception e) {
		result = "Faculty with id is not deleted";
	
	}
		return result;
	}
}
