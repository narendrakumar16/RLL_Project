package com.admin.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.admin.entity.AddAttendance;
import com.admin.service.AddAttendanceService;

@RestController
public class AddAttendanceController {
	@Autowired
	private AddAttendanceService Attservice;

	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping(value = "/getAttendanceList")
	public List<AddAttendance> fetchAddAttendanceList() {
		List<AddAttendance> getattendance = new ArrayList<AddAttendance>();
		getattendance = Attservice.fetchAddAttendanceList();
		return getattendance;
	}

	@CrossOrigin(origins = "http://localhost:4200")
	@PostMapping(value = "/addattendance")
	public AddAttendance saveAddAttendance(@RequestBody AddAttendance addattendance) {
		return Attservice.saveAddAttedanceToDB(addattendance);
	}

	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping("/getattendancebyid/{studID}")
	public AddAttendance fetchAddAttendanceById(@PathVariable int studID) {
		return Attservice.fetchAddAttendanceById(studID).get();
	}
}