package com.admin.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.admin.entity.AddAssignment;
import com.admin.service.AddAssignmentService;

@RestController
public class AddAssignmentController {
	@Autowired
	private AddAssignmentService Assservice;

	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping(value = "/getAssignmentList")
	public List<AddAssignment> fetchAssignmentList() {
		List<AddAssignment> getassignment = new ArrayList<AddAssignment>();
		getassignment = Assservice.fetchAddAssignmentList();
		return getassignment;
	}

	@CrossOrigin(origins = "http://localhost:4200")
	@PostMapping(value = "/addassignment")
	public AddAssignment saveAddAssignment(@RequestBody AddAssignment addasignment) {
		return Assservice.saveAddAssignmentToDB(addasignment);
	}

	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping("/getassignmentbyid/{studID}")
	public AddAssignment fetchAddAssignmentById(@PathVariable int studID) {
		return Assservice.fetchAddAssignmentById(studID).get();
	}
}