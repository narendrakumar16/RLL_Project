package com.admin.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.admin.entity.AddLibrarian;
import com.admin.service.AddLibrarianService;

@RestController
public class AddLibrarianController {
	@Autowired
	private AddLibrarianService libservice;

	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping(value = "/getlibrarianlist")
	public List<AddLibrarian> fetchLibrarianList() {
		List<AddLibrarian> librarians = new ArrayList<AddLibrarian>();
		librarians = libservice.fetchLibrarianList();
		return librarians;
	}

	@CrossOrigin(origins = "http://localhost:4200")
	@PostMapping(value = "/addlibrarian")
	public AddLibrarian saveLibrarian(@RequestBody AddLibrarian librarian) {
		return libservice.saveLibrarianToDB(librarian);
	}

	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping("/getlibrarianbyid/{lid}")
	public AddLibrarian fetchLibrarinById(@PathVariable int lid) {
		return libservice.fetchLibrarianById(lid).get();
	}

	@CrossOrigin(origins = "http://localhost:4200")
	@DeleteMapping("/deletelibrarianbyid/{lid}")
	public String DeleteLibrarinById(@PathVariable int lid) {
		return libservice.deleteLibrarianById(lid);
	}

}
